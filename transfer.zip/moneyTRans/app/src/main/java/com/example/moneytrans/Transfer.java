package com.example.moneytrans;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class Transfer extends AppCompatActivity {

    private EditText setMoney;
    private EditText Amount;
    private Button Set, TransferButton;
    private TextView Savings;
    private TextView newBalance;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transfer);

        Set = findViewById(R.id.SetButton);
        TransferButton = findViewById(R.id.TransferButton);
        setMoney = findViewById(R.id.setMoney);
        Amount = findViewById(R.id.Amount);
        Savings = findViewById(R.id.Savings);
        newBalance = findViewById(R.id.newBalance);
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);


        Set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double temp = 0;

                String str = setMoney.getText().toString().trim();//trim() to remove the first empty space
                if (TextUtils.isEmpty(str)) {
                    builder.setMessage("Please enter a value to set.");
                    builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                        }
                    });
                    AlertDialog ad = builder.create();
                    ad.show();

                } else {
                    temp = Double.parseDouble(setMoney.getText().toString());
                    Savings.setText(temp + " $");
                }
            }
        });

        TransferButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double temp2 = 0;

                String str = Amount.getText().toString().trim();//trim() to remove the first empty space
               // double temp = Double.parseDouble(Savings.getText().toString());              //This seems wrong ..


                if (TextUtils.isEmpty(str)) {
                    builder.setMessage("Please enter a value to transfer .");
                    builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                        }
                    });
                    AlertDialog ad = builder.create();
                    ad.show();

                } /*else if (temp == 0) {
                    builder.setMessage("Please set your balance first .");
                    builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                        }
                    });
                    AlertDialog ad = builder.create();
                    ad.show();

                } else if (temp < tempAmount) {
                    builder.setMessage("You do not have enough money in your balance!");
                    builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                        }
                    });
                    AlertDialog ad = builder.create();
                    ad.show();

                }
                */
                else {
                    //temp2 = Double.parseDouble(Amount.getText().toString());
                    double tempAmount = Double.parseDouble(Amount.getText().toString());
                    newBalance.setText(tempAmount + " $");
                }

            }
        });
    }
}